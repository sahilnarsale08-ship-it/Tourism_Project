# 🌍 TRAVELVERSE – AI-Powered Smart Tourism & Trip Planner

A modern, multi-page Streamlit web application for exploring Indian destinations, planning trips, calculating budgets, chatting with an AI travel assistant, and more. Designed as a complete college final-year / major project.

## ✨ Features

- **Home** – Attractive landing page with hero, search, popular & trending destinations
- **Explore India** – Filterable destination cards + interactive Folium map
- **AI Travel Assistant** – Rule-based chatbot for suggestions, itineraries, packing tips
- **Smart Trip Planner** – Custom itinerary generator with downloadable plan
- **Budget Calculator** – Interactive cost estimation with Plotly charts
- **Hotel Booking Simulation** – Search, filter and simulate bookings
- **Transportation Planner** – Compare flight / train / bus / car options
- **Weather** – Mock weather + travel recommendation
- **Wishlist** – Save destinations (SQLite)
- **Reviews & Ratings** – Submit and view reviews with charts
- **Travel Gallery** – Category-based visual gallery
- **Analytics Dashboard** – KPIs and interactive Plotly visualizations
- **Contact** – About & contact form

## 🛠️ Tech Stack

- Python 3.9+
- Streamlit
- Pandas, NumPy
- Plotly
- Folium + streamlit-folium
- SQLite
- Custom CSS (glassmorphism, gradients)

## 📁 Project Structure

```
TRAVELVERSE/
├── app.py                 # Home page
├── utils.py               # Shared CSS, data loaders, DB helpers
├── requirements.txt
├── tourism_data.csv       # 50 Indian destinations
├── hotels_data.csv
├── reviews.csv
├── README.md
├── pages/
│   ├── 1_Explore.py
│   ├── 2_AI_Assistant.py
│   ├── 3_Trip_Planner.py
│   ├── 4_Budget.py
│   ├── 5_Hotels.py
│   ├── 6_Transport.py
│   ├── 7_Weather.py
│   ├── 8_Wishlist.py
│   ├── 9_Reviews.py
│   ├── 10_Gallery.py
│   ├── 11_Dashboard.py
│   └── 12_Contact.py
├── assets/images/
└── database/              # SQLite created automatically
```

## 🚀 Installation & Run

1. **Clone / navigate to the project folder**
   ```bash
   cd TRAVELVERSE
   ```

2. **Create virtual environment (recommended)**
   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS / Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   streamlit run app.py
   ```

5. Open the URL shown in the terminal (usually http://localhost:8501)

## 📦 Requirements

```
streamlit>=1.28.0
pandas>=2.0.0
numpy>=1.24.0
plotly>=5.15.0
matplotlib>=3.7.0
folium>=0.14.0
streamlit-folium>=0.15.0
requests>=2.31.0
Pillow>=10.0.0
```

## 📝 Notes for Evaluation / Demo

- All data is sample/demo data focused on **Indian tourism**.
- AI Assistant uses a rich **rule-based** fallback (no external API key required).
- Weather uses **mock data** for reliability during offline demos.
- Hotel booking and contact form are **simulations** only.
- Wishlist and Reviews are stored in local **SQLite**.
- Itinerary can be **downloaded** as a text file.
- The UI uses custom CSS for a modern travel-platform look (gradients, glass cards, hover effects).

## 🎓 Suitable For

- Final Year / Major Project
- Mini Project
- Streamlit / Python portfolio demonstration

---

**TRAVELVERSE** — Discover India, Create Memories 🇮🇳
