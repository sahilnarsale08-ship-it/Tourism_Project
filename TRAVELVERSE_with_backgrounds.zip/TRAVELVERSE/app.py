import streamlit as st
import pandas as pd
from utils import (
    load_css, load_tourism_data, set_page_background, PAGE_BACKGROUNDS,
    init_db
)

st.set_page_config(
    page_title="TRAVELVERSE | Discover India",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

load_css()
set_page_background(PAGE_BACKGROUNDS["home"], overlay_opacity=0.78)
init_db()

df = load_tourism_data()

# Hero
st.markdown("""
<div class="hero">
    <h1>🌍 TRAVELVERSE</h1>
    <p>AI-Powered Smart Tourism & Trip Planner for Incredible India</p>
    <p style="font-size:1rem; opacity:0.9;">Discover destinations • Plan trips • Calculate budgets • Chat with AI</p>
</div>
""", unsafe_allow_html=True)

# Quick search
st.markdown('<p class="section-header">🔍 Quick Search</p>', unsafe_allow_html=True)
col1, col2, col3 = st.columns([3, 1, 1])
with col1:
    search = st.text_input("Search destinations, states or categories", placeholder="e.g. Goa, Mountains, Rajasthan...")
with col2:
    category_filter = st.selectbox("Category", ["All"] + (sorted(df["category"].unique().tolist()) if not df.empty else []))
with col3:
    st.write("")  # spacer
    st.write("")

if not df.empty:
    filtered = df.copy()
    if search:
        mask = (
            filtered["name"].str.contains(search, case=False, na=False) |
            filtered["state"].str.contains(search, case=False, na=False) |
            filtered["city"].str.contains(search, case=False, na=False) |
            filtered["category"].str.contains(search, case=False, na=False)
        )
        filtered = filtered[mask]
    if category_filter != "All":
        filtered = filtered[filtered["category"] == category_filter]

    # Popular / Top rated
    st.markdown('<p class="section-header">⭐ Popular Destinations</p>', unsafe_allow_html=True)
    top = filtered.nlargest(6, "rating") if not filtered.empty else df.nlargest(6, "rating")

    cols = st.columns(3)
    for idx, (_, row) in enumerate(top.iterrows()):
        with cols[idx % 3]:
            st.markdown(f"""
            <div class="dest-card">
                <img src="{row['image_url']}" alt="{row['name']}" onerror="this.src='https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=400'">
                <div class="dest-card-body">
                    <div class="dest-title">{row['name']}</div>
                    <div class="dest-meta">📍 {row['city']}, {row['state']} • {row['category']}</div>
                    <span class="rating-badge">★ {row['rating']}</span>
                    <span class="budget-tag">₹{int(row['estimated_budget']):,}</span>
                    <p style="font-size:0.85rem; margin-top:0.6rem; color:#555;">{row['description'][:90]}...</p>
                </div>
            </div>
            """, unsafe_allow_html=True)

    # Stats row
    st.markdown('<p class="section-header">📊 At a Glance</p>', unsafe_allow_html=True)
    k1, k2, k3, k4 = st.columns(4)
    with k1:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">Destinations</div>
            <div class="kpi-value">{len(df)}</div>
        </div>
        """, unsafe_allow_html=True)
    with k2:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">States Covered</div>
            <div class="kpi-value">{df['state'].nunique()}</div>
        </div>
        """, unsafe_allow_html=True)
    with k3:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">Avg Rating</div>
            <div class="kpi-value">{df['rating'].mean():.1f}</div>
        </div>
        """, unsafe_allow_html=True)
    with k4:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">Categories</div>
            <div class="kpi-value">{df['category'].nunique()}</div>
        </div>
        """, unsafe_allow_html=True)

    # Categories
    st.markdown('<p class="section-header">🗂️ Browse by Category</p>', unsafe_allow_html=True)
    cats = df["category"].value_counts()
    cat_cols = st.columns(min(5, len(cats)))
    for i, (cat, count) in enumerate(cats.items()):
        with cat_cols[i % len(cat_cols)]:
            st.markdown(f'<span class="cat-pill">{cat} ({count})</span>', unsafe_allow_html=True)

else:
    st.warning("Tourism data could not be loaded.")

st.markdown("""
<div class="footer">
    <strong>TRAVELVERSE</strong> — Discover India, Create Memories 🇮🇳<br>
    Built with Streamlit • Final Year / Major Project
</div>
""", unsafe_allow_html=True)
