import streamlit as st
import pandas as pd
import sqlite3
import os
from pathlib import Path

BASE_DIR = Path(__file__).parent
DATA_PATH = BASE_DIR / "tourism_data.csv"
HOTELS_PATH = BASE_DIR / "hotels_data.csv"
REVIEWS_PATH = BASE_DIR / "reviews.csv"
DB_PATH = BASE_DIR / "database" / "tourism.db"

def load_css():
    st.markdown("""
    <style>
    /* Main theme - Ocean & Sunset inspired */
    :root {
        --primary: #0077B6;
        --secondary: #00B4D8;
        --accent: #FF6B35;
        --dark: #023E8A;
        --light: #CAF0F8;
        --gradient: linear-gradient(135deg, #0077B6 0%, #00B4D8 50%, #90E0EF 100%);
        --sunset: linear-gradient(135deg, #FF6B35 0%, #F7C59F 50%, #EFEFD0 100%);
    }
    
    /* Hide default Streamlit elements slightly */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    
    /* Hero section */
    .hero {
        background: linear-gradient(135deg, #0077B6 0%, #023E8A 40%, #00B4D8 100%);
        padding: 3.5rem 2rem;
        border-radius: 20px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: 0 15px 35px rgba(0,119,182,0.3);
        position: relative;
        overflow: hidden;
    }
    .hero h1 {
        font-size: 2.8rem;
        font-weight: 800;
        margin-bottom: 0.5rem;
        text-shadow: 2px 2px 8px rgba(0,0,0,0.2);
    }
    .hero p {
        font-size: 1.25rem;
        opacity: 0.95;
        margin-bottom: 1.5rem;
    }
    
    /* Glassmorphism cards */
    .glass-card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.4);
        padding: 1.5rem;
        box-shadow: 0 8px 32px rgba(0, 119, 182, 0.12);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        margin-bottom: 1rem;
    }
    .glass-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 15px 40px rgba(0, 119, 182, 0.2);
    }
    
    /* Destination card */
    .dest-card {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        transition: all 0.3s ease;
        height: 100%;
        border: 1px solid #e8f4f8;
    }
    .dest-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 16px 40px rgba(0,119,182,0.18);
    }
    .dest-card img {
        width: 100%;
        height: 180px;
        object-fit: cover;
    }
    .dest-card-body {
        padding: 1.2rem;
    }
    .dest-title {
        font-size: 1.15rem;
        font-weight: 700;
        color: #023E8A;
        margin-bottom: 0.3rem;
    }
    .dest-meta {
        font-size: 0.85rem;
        color: #666;
        margin-bottom: 0.5rem;
    }
    .rating-badge {
        background: linear-gradient(90deg, #FF6B35, #FF8C42);
        color: white;
        padding: 0.2rem 0.6rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        display: inline-block;
    }
    .budget-tag {
        background: #E8F5E9;
        color: #2E7D32;
        padding: 0.2rem 0.6rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    /* Buttons */
    .stButton > button {
        border-radius: 12px !important;
        font-weight: 600 !important;
        transition: all 0.25s ease !important;
        border: none !important;
    }
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,119,182,0.25) !important;
    }
    
    /* KPI cards */
    .kpi-card {
        background: linear-gradient(135deg, #0077B6, #00B4D8);
        color: white;
        padding: 1.5rem;
        border-radius: 16px;
        text-align: center;
        box-shadow: 0 8px 25px rgba(0,119,182,0.25);
    }
    .kpi-value {
        font-size: 2.2rem;
        font-weight: 800;
        margin: 0.3rem 0;
    }
    .kpi-label {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    
    /* Sidebar */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #023E8A 0%, #0077B6 100%);
    }
    [data-testid="stSidebar"] * {
        color: white !important;
    }
    [data-testid="stSidebar"] .stSelectbox label,
    [data-testid="stSidebar"] .stMarkdown {
        color: white !important;
    }
    
    /* Section headers */
    .section-header {
        font-size: 1.8rem;
        font-weight: 700;
        color: #023E8A;
        margin: 1.5rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 3px solid #00B4D8;
        display: inline-block;
    }
    
    /* Chat bubbles */
    .user-msg {
        background: linear-gradient(135deg, #0077B6, #00B4D8);
        color: white;
        padding: 0.9rem 1.2rem;
        border-radius: 18px 18px 4px 18px;
        margin: 0.5rem 0;
        max-width: 80%;
        margin-left: auto;
        box-shadow: 0 4px 12px rgba(0,119,182,0.2);
    }
    .bot-msg {
        background: #f0f7fa;
        color: #023E8A;
        padding: 0.9rem 1.2rem;
        border-radius: 18px 18px 18px 4px;
        margin: 0.5rem 0;
        max-width: 85%;
        border: 1px solid #d0e8f0;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    
    /* Category pills */
    .cat-pill {
        display: inline-block;
        background: #E3F2FD;
        color: #1565C0;
        padding: 0.35rem 0.9rem;
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 600;
        margin: 0.2rem;
    }
    
    /* Checklist */
    .checklist-item {
        background: white;
        padding: 0.8rem 1rem;
        border-radius: 10px;
        margin: 0.4rem 0;
        border-left: 4px solid #00B4D8;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    /* Footer */
    .footer {
        text-align: center;
        padding: 2rem;
        color: #666;
        font-size: 0.9rem;
        margin-top: 3rem;
        border-top: 1px solid #e0e0e0;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .hero h1 { font-size: 1.8rem; }
        .hero p { font-size: 1rem; }
    }
    </style>
    """, unsafe_allow_html=True)

@st.cache_data
def load_tourism_data():
    try:
        if DATA_PATH.exists():
            df = pd.read_csv(DATA_PATH)
            return df
        else:
            st.error("Tourism data file not found. Please ensure tourism_data.csv exists.")
            return pd.DataFrame()
    except Exception as e:
        st.error(f"Error loading tourism data: {e}")
        return pd.DataFrame()

@st.cache_data
def load_hotels_data():
    try:
        if HOTELS_PATH.exists():
            return pd.read_csv(HOTELS_PATH)
        return pd.DataFrame()
    except Exception as e:
        st.error(f"Error loading hotels data: {e}")
        return pd.DataFrame()

def init_db():
    os.makedirs(DB_PATH.parent, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Reviews table
    c.execute('''
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destination_id INTEGER,
            destination_name TEXT,
            user_name TEXT,
            rating INTEGER,
            review_text TEXT,
            date TEXT
        )
    ''')
    
    # Wishlist table
    c.execute('''
        CREATE TABLE IF NOT EXISTS wishlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destination_id INTEGER UNIQUE,
            destination_name TEXT,
            state TEXT,
            category TEXT,
            rating REAL,
            estimated_budget INTEGER,
            added_at TEXT
        )
    ''')
    
    # Seed reviews if empty
    c.execute("SELECT COUNT(*) FROM reviews")
    if c.fetchone()[0] == 0 and REVIEWS_PATH.exists():
        reviews_df = pd.read_csv(REVIEWS_PATH)
        for _, row in reviews_df.iterrows():
            c.execute('''
                INSERT INTO reviews (destination_id, destination_name, user_name, rating, review_text, date)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (int(row['destination_id']), row['destination_name'], row['user_name'],
                  int(row['rating']), row['review_text'], row['date']))
    
    conn.commit()
    conn.close()

def get_reviews():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM reviews ORDER BY date DESC", conn)
    conn.close()
    return df

def add_review(destination_id, destination_name, user_name, rating, review_text, date):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        INSERT INTO reviews (destination_id, destination_name, user_name, rating, review_text, date)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (destination_id, destination_name, user_name, rating, review_text, date))
    conn.commit()
    conn.close()

def get_wishlist():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM wishlist ORDER BY added_at DESC", conn)
    conn.close()
    return df

def add_to_wishlist(dest):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        from datetime import datetime
        c.execute('''
            INSERT OR IGNORE INTO wishlist (destination_id, destination_name, state, category, rating, estimated_budget, added_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (int(dest['id']), dest['name'], dest['state'], dest['category'],
              float(dest['rating']), int(dest['estimated_budget']),
              datetime.now().strftime("%Y-%m-%d %H:%M")))
        conn.commit()
        success = True
    except Exception:
        success = False
    conn.close()
    return success

def remove_from_wishlist(destination_id):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM wishlist WHERE destination_id = ?", (int(destination_id),))
    conn.commit()
    conn.close()

def is_in_wishlist(destination_id):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT 1 FROM wishlist WHERE destination_id = ?", (int(destination_id),))
    exists = c.fetchone() is not None
    conn.close()
    return exists

# Mock weather data for popular destinations
MOCK_WEATHER = {
    "Agra": {"temp": 28, "condition": "Sunny", "humidity": 45, "wind": 12, "rain": 5},
    "Jaipur": {"temp": 32, "condition": "Clear", "humidity": 35, "wind": 15, "rain": 2},
    "Goa": {"temp": 30, "condition": "Partly Cloudy", "humidity": 75, "wind": 18, "rain": 20},
    "Manali": {"temp": 15, "condition": "Cool & Clear", "humidity": 55, "wind": 10, "rain": 10},
    "Alleppey": {"temp": 29, "condition": "Humid", "humidity": 80, "wind": 8, "rain": 30},
    "Varanasi": {"temp": 27, "condition": "Hazy", "humidity": 60, "wind": 9, "rain": 5},
    "Rishikesh": {"temp": 22, "condition": "Pleasant", "humidity": 50, "wind": 11, "rain": 15},
    "Port Blair": {"temp": 31, "condition": "Tropical", "humidity": 78, "wind": 20, "rain": 25},
    "Hampi": {"temp": 33, "condition": "Hot & Dry", "humidity": 40, "wind": 14, "rain": 0},
    "Darjeeling": {"temp": 14, "condition": "Misty", "humidity": 70, "wind": 8, "rain": 20},
    "Udaipur": {"temp": 29, "condition": "Sunny", "humidity": 42, "wind": 10, "rain": 3},
    "Leh": {"temp": 8, "condition": "Cold & Clear", "humidity": 30, "wind": 25, "rain": 0},
    "Mysore": {"temp": 26, "condition": "Pleasant", "humidity": 55, "wind": 9, "rain": 10},
    "Shimla": {"temp": 16, "condition": "Cool", "humidity": 60, "wind": 12, "rain": 15},
    "Jaisalmer": {"temp": 35, "condition": "Hot & Dry", "humidity": 25, "wind": 20, "rain": 0},
    "Munnar": {"temp": 18, "condition": "Misty Cool", "humidity": 75, "wind": 7, "rain": 25},
    "Amritsar": {"temp": 25, "condition": "Clear", "humidity": 50, "wind": 11, "rain": 5},
    "Ooty": {"temp": 17, "condition": "Cool", "humidity": 65, "wind": 9, "rain": 20},
    "Aurangabad": {"temp": 31, "condition": "Hot", "humidity": 45, "wind": 13, "rain": 5},
    "Gokarna": {"temp": 29, "condition": "Breezy", "humidity": 70, "wind": 16, "rain": 15},
}

def get_weather(city):
    # Try to match city name loosely
    for key in MOCK_WEATHER:
        if key.lower() in city.lower() or city.lower() in key.lower():
            return MOCK_WEATHER[key]
    # Default
    return {"temp": 27, "condition": "Pleasant", "humidity": 55, "wind": 12, "rain": 10}

def get_weather_recommendation(weather):
    temp = weather["temp"]
    rain = weather["rain"]
    if rain > 40:
        return "⚠️ High chance of rain. Carry umbrella and plan indoor activities."
    if temp > 35:
        return "🔥 Very hot. Stay hydrated, avoid afternoon sun, prefer early mornings."
    if temp < 10:
        return "❄️ Cold weather. Pack warm clothes and enjoy the crisp air!"
    if 15 <= temp <= 30 and rain < 20:
        return "✅ Excellent time to visit! Weather is pleasant and favorable."
    return "👍 Decent conditions. Check local forecast before outdoor plans."


def set_page_background(image_url, overlay_opacity=0.72):
    """
    Sets a full-page background image with a light overlay for readability.
    Call this near the top of each page after load_css().
    """
    st.markdown(f"""
    <style>
    .stApp {{
        background-image: linear-gradient(
            rgba(255, 255, 255, {overlay_opacity}),
            rgba(255, 255, 255, {overlay_opacity})
        ), url("{image_url}");
        background-size: cover;
        background-position: center center;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }}
    /* Ensure content is readable */
    [data-testid="stAppViewContainer"] > .main {{
        background: transparent;
    }}
    .block-container {{
        background: transparent;
        padding-top: 1.5rem;
    }}
    </style>
    """, unsafe_allow_html=True)


# Curated background images for each section (Unsplash - free to use)
PAGE_BACKGROUNDS = {
    "home": "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=1920&q=80",
    "explore": "https://images.unsplash.com/photo-1506461883276-594a12b74c47?auto=format&fit=crop&w=1920&q=80",
    "ai_assistant": "https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1920&q=80",
    "trip_planner": "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1920&q=80",
    "budget": "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1920&q=80",
    "hotels": "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1920&q=80",
    "transport": "https://images.unsplash.com/photo-1544620341-1adc1bce8b32?auto=format&fit=crop&w=1920&q=80",
    "weather": "https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?auto=format&fit=crop&w=1920&q=80",
    "wishlist": "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1920&q=80",
    "reviews": "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1920&q=80",
    "gallery": "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1920&q=80",
    "dashboard": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1920&q=80",
    "contact": "https://images.unsplash.com/photo-1423666639041-f56000c27a9a?auto=format&fit=crop&w=1920&q=80",
}
