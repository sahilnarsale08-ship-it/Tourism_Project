import streamlit as st
from utils import (
    load_css, set_page_background, PAGE_BACKGROUNDS,
    load_tourism_data, get_weather, get_weather_recommendation, MOCK_WEATHER
)

st.set_page_config(page_title="Weather | TRAVELVERSE", page_icon="🌤️", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["weather"], overlay_opacity=0.75)

st.markdown('<p class="section-header">🌤️ Weather & Travel Advice</p>', unsafe_allow_html=True)
st.caption("Mock weather data for popular destinations (reliable for offline demos)")

df = load_tourism_data()
cities = sorted(MOCK_WEATHER.keys())
if not df.empty:
    extra = sorted(set(df["city"].tolist()) - set(cities))
    cities = cities + extra

city = st.selectbox("Select City / Destination", cities, index=0)

weather = get_weather(city)
rec = get_weather_recommendation(weather)

# Big weather cards
c1, c2, c3, c4, c5 = st.columns(5)
c1.markdown(f"""
<div class="kpi-card">
    <div class="kpi-label">Temperature</div>
    <div class="kpi-value">{weather['temp']}°C</div>
</div>
""", unsafe_allow_html=True)
c2.markdown(f"""
<div class="kpi-card">
    <div class="kpi-label">Condition</div>
    <div class="kpi-value" style="font-size:1.3rem;">{weather['condition']}</div>
</div>
""", unsafe_allow_html=True)
c3.markdown(f"""
<div class="kpi-card">
    <div class="kpi-label">Humidity</div>
    <div class="kpi-value">{weather['humidity']}%</div>
</div>
""", unsafe_allow_html=True)
c4.markdown(f"""
<div class="kpi-card">
    <div class="kpi-label">Wind</div>
    <div class="kpi-value">{weather['wind']} km/h</div>
</div>
""", unsafe_allow_html=True)
c5.markdown(f"""
<div class="kpi-card">
    <div class="kpi-label">Rain Chance</div>
    <div class="kpi-value">{weather['rain']}%</div>
</div>
""", unsafe_allow_html=True)

st.markdown(f"""
<div class="glass-card" style="margin-top:1.5rem;">
    <h3 style="color:#023E8A; margin-top:0;">Travel Recommendation</h3>
    <p style="font-size:1.15rem;">{rec}</p>
</div>
""", unsafe_allow_html=True)

# Related destinations from data
if not df.empty:
    related = df[df["city"].str.contains(city, case=False, na=False) | df["name"].str.contains(city, case=False, na=False)]
    if not related.empty:
        st.markdown("### Related Destinations in Data")
        for _, row in related.iterrows():
            st.markdown(f"- **{row['name']}** ({row['state']}) — Best season: {row['best_season']}")
