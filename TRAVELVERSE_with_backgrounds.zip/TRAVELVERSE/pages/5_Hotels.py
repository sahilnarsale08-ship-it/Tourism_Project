import streamlit as st
import pandas as pd
from utils import load_css, set_page_background, PAGE_BACKGROUNDS, load_hotels_data

st.set_page_config(page_title="Hotels | TRAVELVERSE", page_icon="🏨", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["hotels"], overlay_opacity=0.76)

st.markdown('<p class="section-header">🏨 Hotel Booking Simulation</p>', unsafe_allow_html=True)
st.caption("Browse and simulate booking (demo only – no real payments)")

hotels = load_hotels_data()

if hotels.empty:
    st.warning("Hotel data not found.")
    st.stop()

c1, c2, c3, c4 = st.columns(4)
with c1:
    dests = ["All"] + sorted(hotels["destination"].unique().tolist())
    dest = st.selectbox("Destination", dests)
with c2:
    types = ["All"] + sorted(hotels["hotel_type"].unique().tolist())
    htype = st.selectbox("Hotel Type", types)
with c3:
    max_price = st.slider("Max Price / Night (₹)", 500, 40000, 20000, 500)
with c4:
    min_rating = st.slider("Min Rating", 3.5, 5.0, 4.0, 0.1)

filtered = hotels.copy()
if dest != "All":
    filtered = filtered[filtered["destination"] == dest]
if htype != "All":
    filtered = filtered[filtered["hotel_type"] == htype]
filtered = filtered[(filtered["price_per_night"] <= max_price) & (filtered["rating"] >= min_rating)]

st.write(f"**{len(filtered)}** hotels match your filters")

for _, row in filtered.iterrows():
    with st.container():
        st.markdown(f"""
        <div class="glass-card">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap;">
                <div>
                    <h3 style="margin:0; color:#023E8A;">{row['name']}</h3>
                    <p style="margin:0.3rem 0; color:#555;">📍 {row['location']} • {row['destination']}, {row['state']}</p>
                    <span class="rating-badge">★ {row['rating']}</span>
                    <span class="cat-pill">{row['hotel_type']}</span>
                    <p style="margin-top:0.6rem; font-size:0.9rem;"><b>Facilities:</b> {row['facilities']}</p>
                    <p style="font-size:0.9rem;"><b>Rooms:</b> {row['room_types']}</p>
                </div>
                <div style="text-align:right;">
                    <div style="font-size:1.6rem; font-weight:800; color:#0077B6;">₹{int(row['price_per_night']):,}</div>
                    <div style="font-size:0.85rem; color:#666;">per night</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        bcol1, bcol2, _ = st.columns([1, 1, 4])
        with bcol1:
            if st.button("Simulate Book", key=f"book_{row['id']}"):
                st.success(f"✅ Simulated booking for **{row['name']}** — Confirmation #TV{row['id']:04d} (demo only)")
        with bcol2:
            nights = st.number_input("Nights", 1, 14, 2, key=f"n_{row['id']}")
            st.caption(f"Est. total: ₹{int(row['price_per_night'] * nights):,}")
