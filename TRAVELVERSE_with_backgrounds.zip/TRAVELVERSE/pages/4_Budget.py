import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from utils import load_css, set_page_background, PAGE_BACKGROUNDS, load_tourism_data

st.set_page_config(page_title="Budget Calculator | TRAVELVERSE", page_icon="💰", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["budget"], overlay_opacity=0.78)

st.markdown('<p class="section-header">💰 Smart Budget Calculator</p>', unsafe_allow_html=True)
st.caption("Estimate your trip cost with interactive breakdown")

df = load_tourism_data()

col1, col2 = st.columns([1, 1])
with col1:
    dest = st.selectbox(
        "Destination",
        df["name"].tolist() if not df.empty else ["Goa Beaches"]
    )
    days = st.slider("Days", 1, 14, 5)
    people = st.number_input("Number of People", 1, 12, 2)
    travel_style = st.select_slider("Travel Style", ["Budget", "Standard", "Premium", "Luxury"], value="Standard")

with col2:
    transport_mode = st.selectbox("Main Transport", ["Train", "Flight", "Bus", "Self-drive"])
    include_hotel = st.checkbox("Include Hotel", value=True)
    include_food = st.checkbox("Include Food", value=True)
    include_activities = st.checkbox("Include Activities / Entry fees", value=True)
    include_local_transport = st.checkbox("Include Local Transport", value=True)

# Base estimates
base_row = df[df["name"] == dest].iloc[0] if not df.empty and dest in df["name"].values else None
base_budget = int(base_row["estimated_budget"]) if base_row is not None else 10000

multipliers = {"Budget": 0.7, "Standard": 1.0, "Premium": 1.5, "Luxury": 2.4}
style_mult = multipliers[travel_style]

# Rough component costs (per person per day averages adjusted)
hotel_ppd = {"Budget": 800, "Standard": 1800, "Premium": 4000, "Luxury": 9000}[travel_style]
food_ppd = {"Budget": 400, "Standard": 800, "Premium": 1500, "Luxury": 3000}[travel_style]
act_ppd = {"Budget": 300, "Standard": 600, "Premium": 1200, "Luxury": 2500}[travel_style]
local_ppd = {"Budget": 200, "Standard": 400, "Premium": 700, "Luxury": 1200}[travel_style]

transport_base = {"Train": 1500, "Bus": 800, "Flight": 5500, "Self-drive": 2500}[transport_mode]
# scale transport a bit by distance proxy from budget
transport_total = transport_base * style_mult * people

hotel_total = hotel_ppd * days * people if include_hotel else 0
food_total = food_ppd * days * people if include_food else 0
act_total = act_ppd * days * people if include_activities else 0
local_total = local_ppd * days * people if include_local_transport else 0

grand_total = transport_total + hotel_total + food_total + act_total + local_total

# KPI cards
k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Estimated Cost", f"₹{int(grand_total):,}")
k2.metric("Per Person", f"₹{int(grand_total / people):,}")
k3.metric("Per Day (group)", f"₹{int(grand_total / days):,}")
k4.metric("Style Multiplier", f"{style_mult}x")

# Breakdown chart
labels = []
values = []
if transport_total > 0:
    labels.append("Transport")
    values.append(transport_total)
if hotel_total > 0:
    labels.append("Hotel")
    values.append(hotel_total)
if food_total > 0:
    labels.append("Food")
    values.append(food_total)
if act_total > 0:
    labels.append("Activities")
    values.append(act_total)
if local_total > 0:
    labels.append("Local Transport")
    values.append(local_total)

if values:
    fig = px.pie(
        names=labels, values=values,
        title="Cost Breakdown",
        color_discrete_sequence=px.colors.sequential.Blues_r
    )
    fig.update_traces(textposition="inside", textinfo="percent+label")
    fig.update_layout(margin=dict(t=50, b=20, l=20, r=20))
    st.plotly_chart(fig, use_container_width=True)

    # Bar for clarity
    fig2 = go.Figure(data=[go.Bar(x=labels, y=values, marker_color="#0077B6")])
    fig2.update_layout(title="Cost by Category (₹)", yaxis_title="Amount (₹)", margin=dict(t=50))
    st.plotly_chart(fig2, use_container_width=True)

st.info("💡 These are approximate demo estimates. Actual prices vary by season, booking time and exact choices.")
