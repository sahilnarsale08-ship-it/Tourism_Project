import streamlit as st
from utils import (
    load_css, set_page_background, PAGE_BACKGROUNDS,
    get_wishlist, remove_from_wishlist, load_tourism_data, add_to_wishlist
)

st.set_page_config(page_title="Wishlist | TRAVELVERSE", page_icon="❤️", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["wishlist"], overlay_opacity=0.76)

st.markdown('<p class="section-header">❤️ My Wishlist</p>', unsafe_allow_html=True)
st.caption("Saved destinations stored locally in SQLite")

wl = get_wishlist()

if wl.empty:
    st.info("Your wishlist is empty. Go to **Explore** and click the Wishlist button on any destination.")
    df = load_tourism_data()
    if not df.empty:
        st.markdown("#### Quick add popular ones")
        top = df.nlargest(5, "rating")
        cols = st.columns(5)
        for i, (_, row) in enumerate(top.iterrows()):
            with cols[i]:
                if st.button(f"+ {row['name'][:12]}", key=f"qa_{row['id']}"):
                    add_to_wishlist(row)
                    st.rerun()
else:
    st.success(f"You have **{len(wl)}** saved destinations")
    for _, row in wl.iterrows():
        st.markdown(f"""
        <div class="glass-card">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap;">
                <div>
                    <h3 style="margin:0; color:#023E8A;">{row['destination_name']}</h3>
                    <p style="margin:0.2rem 0; color:#555;">{row['state']} • {row['category']}</p>
                    <span class="rating-badge">★ {row['rating']}</span>
                    <span class="budget-tag">₹{int(row['estimated_budget']):,}</span>
                    <p style="font-size:0.8rem; color:#888; margin-top:0.4rem;">Added: {row['added_at']}</p>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        if st.button("🗑️ Remove", key=f"rm_{row['destination_id']}"):
            remove_from_wishlist(row["destination_id"])
            st.rerun()
