import streamlit as st
from utils import load_css, set_page_background, PAGE_BACKGROUNDS

st.set_page_config(page_title="Contact | TRAVELVERSE", page_icon="📧", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["contact"], overlay_opacity=0.78)

st.markdown('<p class="section-header">📧 About & Contact</p>', unsafe_allow_html=True)

col1, col2 = st.columns([1.2, 1])

with col1:
    st.markdown("""
    <div class="glass-card">
        <h2 style="color:#023E8A; margin-top:0;">About TRAVELVERSE</h2>
        <p>TRAVELVERSE is an AI-powered smart tourism and trip planner focused on <strong>Incredible India</strong>.
        It was built as a complete college final-year / major project demonstrating modern web apps with Streamlit.</p>
        <p><strong>Key features:</strong></p>
        <ul>
            <li>Explore 50+ curated Indian destinations with maps</li>
            <li>Rule-based AI Travel Assistant</li>
            <li>Smart itinerary generator with download</li>
            <li>Interactive budget calculator</li>
            <li>Hotel & transport planners (simulation)</li>
            <li>Weather advice, Wishlist (SQLite), Reviews & Gallery</li>
            <li>Analytics dashboard with Plotly charts</li>
        </ul>
        <p style="margin-bottom:0;">Tech: Python, Streamlit, Pandas, Plotly, Folium, SQLite + custom CSS.</p>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="glass-card">
        <h3 style="color:#023E8A; margin-top:0;">Get in Touch</h3>
        <p>Have feedback or suggestions? Fill the form below (demo – messages are not actually sent).</p>
    </div>
    """, unsafe_allow_html=True)

    with st.form("contact_form"):
        name = st.text_input("Name")
        email = st.text_input("Email")
        subject = st.selectbox("Subject", ["General Feedback", "Bug Report", "Feature Request", "Collaboration"])
        message = st.text_area("Message", height=120)
        sent = st.form_submit_button("Send Message")
        if sent:
            if name and email and message:
                st.success("✅ Thank you! Your message has been recorded (simulation only).")
            else:
                st.error("Please fill all required fields.")

st.markdown("""
<div class="footer">
    <strong>TRAVELVERSE</strong> — Discover India, Create Memories 🇮🇳<br>
    Built with ❤️ using Streamlit • For educational / portfolio use
</div>
""", unsafe_allow_html=True)
