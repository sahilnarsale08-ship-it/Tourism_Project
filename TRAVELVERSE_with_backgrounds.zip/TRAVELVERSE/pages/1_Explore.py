import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium
from utils import (
    load_css, load_tourism_data, set_page_background, PAGE_BACKGROUNDS,
    add_to_wishlist, is_in_wishlist
)

st.set_page_config(page_title="Explore India | TRAVELVERSE", page_icon="🗺️", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["explore"], overlay_opacity=0.75)

st.markdown('<p class="section-header">🗺️ Explore Incredible India</p>', unsafe_allow_html=True)
st.caption("Filter destinations and explore them on an interactive map")

df = load_tourism_data()

if df.empty:
    st.error("No destination data available.")
    st.stop()

# Sidebar-like filters in main area
c1, c2, c3, c4 = st.columns(4)
with c1:
    states = ["All"] + sorted(df["state"].unique().tolist())
    state = st.selectbox("State", states)
with c2:
    cats = ["All"] + sorted(df["category"].unique().tolist())
    category = st.selectbox("Category", cats)
with c3:
    min_rating = st.slider("Min Rating", 3.0, 5.0, 4.0, 0.1)
with c4:
    max_budget = st.slider("Max Budget (₹)", 3000, 35000, 25000, 1000)

filtered = df.copy()
if state != "All":
    filtered = filtered[filtered["state"] == state]
if category != "All":
    filtered = filtered[filtered["category"] == category]
filtered = filtered[(filtered["rating"] >= min_rating) & (filtered["estimated_budget"] <= max_budget)]

st.info(f"Showing **{len(filtered)}** destinations")

# Map
if not filtered.empty:
    avg_lat = filtered["latitude"].mean()
    avg_lon = filtered["longitude"].mean()
    m = folium.Map(location=[avg_lat, avg_lon], zoom_start=5, tiles="CartoDB positron")
    for _, row in filtered.iterrows():
        popup_html = f"""
        <b>{row['name']}</b><br>
        {row['city']}, {row['state']}<br>
        ★ {row['rating']} • ₹{int(row['estimated_budget']):,}<br>
        {row['category']}
        """
        folium.Marker(
            [row["latitude"], row["longitude"]],
            popup=folium.Popup(popup_html, max_width=250),
            tooltip=row["name"],
            icon=folium.Icon(color="blue", icon="info-sign")
        ).add_to(m)
    st_folium(m, width=None, height=420, returned_objects=[])

# Cards
st.markdown("### Destination Cards")
cols = st.columns(3)
for idx, (_, row) in enumerate(filtered.iterrows()):
    with cols[idx % 3]:
        st.markdown(f"""
        <div class="dest-card">
            <img src="{row['image_url']}" alt="{row['name']}"
                 onerror="this.src='https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=400'">
            <div class="dest-card-body">
                <div class="dest-title">{row['name']}</div>
                <div class="dest-meta">📍 {row['city']}, {row['state']}</div>
                <span class="rating-badge">★ {row['rating']}</span>
                <span class="budget-tag">₹{int(row['estimated_budget']):,}</span>
                <p style="font-size:0.82rem;margin-top:0.5rem;color:#555;">{row['description'][:100]}...</p>
                <p style="font-size:0.8rem;color:#0077B6;">Best: {row['best_season']} • {row['days_recommended']} days</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
        if st.button(f"❤️ Wishlist", key=f"wish_{row['id']}"):
            ok = add_to_wishlist(row)
            if ok:
                st.success(f"Added {row['name']} to wishlist!")
            else:
                st.info("Already in wishlist or error occurred.")
