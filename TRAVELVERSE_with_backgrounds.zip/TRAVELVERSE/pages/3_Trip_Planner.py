import streamlit as st
from utils import load_css, set_page_background, PAGE_BACKGROUNDS, load_tourism_data
from datetime import datetime, timedelta

st.set_page_config(page_title="Smart Trip Planner | TRAVELVERSE", page_icon="📅", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["trip_planner"], overlay_opacity=0.76)

st.markdown('<p class="section-header">📅 Smart Trip Planner</p>', unsafe_allow_html=True)
st.caption("Generate a personalized day-by-day itinerary and download it")

df = load_tourism_data()

with st.form("planner_form"):
    col1, col2 = st.columns(2)
    with col1:
        dest_options = df["name"].tolist() if not df.empty else ["Taj Mahal", "Goa Beaches", "Manali"]
        destination = st.selectbox("Primary Destination", dest_options)
        days = st.slider("Number of Days", 1, 10, 4)
        travelers = st.number_input("Travelers", 1, 10, 2)
    with col2:
        start_date = st.date_input("Start Date", datetime.now() + timedelta(days=14))
        interests = st.multiselect(
            "Interests",
            ["Sightseeing", "Adventure", "Food", "Culture", "Relaxation", "Photography", "Shopping"],
            default=["Sightseeing", "Food"]
        )
        pace = st.select_slider("Pace", ["Relaxed", "Balanced", "Packed"], value="Balanced")
    submitted = st.form_submit_button("✨ Generate Itinerary", use_container_width=True)

if submitted or "itinerary" in st.session_state:
    if submitted:
        # Build a simple rule-based itinerary
        row = df[df["name"] == destination].iloc[0] if not df.empty and destination in df["name"].values else None
        plan_lines = []
        plan_lines.append(f"TRAVELVERSE ITINERARY")
        plan_lines.append(f"{'='*40}")
        plan_lines.append(f"Destination : {destination}")
        if row is not None:
            plan_lines.append(f"Location    : {row['city']}, {row['state']}")
            plan_lines.append(f"Category    : {row['category']}")
            plan_lines.append(f"Best Season : {row['best_season']}")
        plan_lines.append(f"Duration    : {days} days")
        plan_lines.append(f"Travelers   : {travelers}")
        plan_lines.append(f"Start Date  : {start_date.strftime('%d %b %Y')}")
        plan_lines.append(f"Pace        : {pace}")
        plan_lines.append(f"Interests   : {', '.join(interests)}")
        plan_lines.append(f"{'='*40}\n")

        activity_pool = {
            "Sightseeing": ["Visit main landmark", "Explore local market", "City walking tour", "Photo spots"],
            "Adventure": ["Adventure activity", "Nature trail / short trek", "Water sports (if available)", "Sunrise viewpoint"],
            "Food": ["Local breakfast experience", "Street food trail", "Traditional dinner", "Café hopping"],
            "Culture": ["Temple / heritage site", "Local craft workshop", "Cultural show / aarti", "Museum visit"],
            "Relaxation": ["Leisure morning", "Spa / Ayurveda (if available)", "Beach / lake time", "Sunset point"],
            "Photography": ["Golden hour shoot", "Iconic viewpoint", "Street photography", "Night lights"],
            "Shopping": ["Handicraft market", "Local souvenirs", "Boutique / mall", "Evening bazaar"]
        }

        for d in range(1, days + 1):
            date = start_date + timedelta(days=d - 1)
            plan_lines.append(f"DAY {d} — {date.strftime('%A, %d %b %Y')}")
            plan_lines.append("-" * 30)
            # Morning
            plan_lines.append("  🌅 Morning")
            if d == 1:
                plan_lines.append("     • Arrival & check-in / settle")
                plan_lines.append("     • Light local exploration")
            else:
                chosen = interests[d % len(interests)] if interests else "Sightseeing"
                acts = activity_pool.get(chosen, ["Explore the area"])
                plan_lines.append(f"     • {acts[0]}")
                if pace != "Relaxed":
                    plan_lines.append(f"     • {acts[1] if len(acts) > 1 else 'Continue exploring'}")
            # Afternoon
            plan_lines.append("  ☀️ Afternoon")
            chosen2 = interests[(d + 1) % len(interests)] if interests else "Food"
            acts2 = activity_pool.get(chosen2, ["Local lunch & rest"])
            plan_lines.append(f"     • {acts2[0]}")
            if pace == "Packed":
                plan_lines.append(f"     • {acts2[1] if len(acts2) > 1 else 'More activities'}")
            else:
                plan_lines.append("     • Lunch & short rest")
            # Evening
            plan_lines.append("  🌙 Evening")
            plan_lines.append("     • Sunset / evening viewpoint")
            plan_lines.append("     • Dinner at a recommended local place")
            if d == days:
                plan_lines.append("     • Pack & prepare for departure (next day)")
            plan_lines.append("")

        plan_lines.append("TIPS")
        plan_lines.append("• Carry cash + UPI, keep copies of ID.")
        plan_lines.append("• Book popular attractions in advance when possible.")
        plan_lines.append("• Respect local customs and dress modestly at religious sites.")
        plan_lines.append("• Stay hydrated and check weather daily.")
        plan_lines.append("\nGenerated by TRAVELVERSE • Have a wonderful trip! 🇮🇳")

        st.session_state.itinerary = "\n".join(plan_lines)

    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.text(st.session_state.itinerary)
    st.markdown('</div>', unsafe_allow_html=True)

    st.download_button(
        label="⬇️ Download Itinerary (.txt)",
        data=st.session_state.itinerary,
        file_name=f"TRAVELVERSE_Itinerary_{destination.replace(' ', '_')}.txt",
        mime="text/plain",
        use_container_width=True
    )
