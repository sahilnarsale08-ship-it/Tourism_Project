import streamlit as st
from utils import load_css, set_page_background, PAGE_BACKGROUNDS, load_tourism_data

st.set_page_config(page_title="Travel Gallery | TRAVELVERSE", page_icon="🖼️", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["gallery"], overlay_opacity=0.70)

st.markdown('<p class="section-header">🖼️ Travel Gallery</p>', unsafe_allow_html=True)
st.caption("Visual inspiration by category")

df = load_tourism_data()
if df.empty:
    st.warning("No data.")
    st.stop()

cats = ["All"] + sorted(df["category"].unique().tolist())
selected = st.selectbox("Filter by Category", cats)

show = df if selected == "All" else df[df["category"] == selected]

# Responsive grid of images
cols = st.columns(3)
for idx, (_, row) in enumerate(show.iterrows()):
    with cols[idx % 3]:
        st.image(row["image_url"], use_container_width=True,
                 caption=f"{row['name']} • {row['city']}, {row['state']}")
        st.markdown(f"<center><span class='rating-badge'>★ {row['rating']}</span> "
                    f"<span class='cat-pill'>{row['category']}</span></center>",
                    unsafe_allow_html=True)
        st.write("")
