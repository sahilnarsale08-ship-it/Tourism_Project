import streamlit as st
import pandas as pd
import plotly.express as px
from utils import load_css, set_page_background, PAGE_BACKGROUNDS

st.set_page_config(page_title="Transport Planner | TRAVELVERSE", page_icon="🚆", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["transport"], overlay_opacity=0.76)

st.markdown('<p class="section-header">🚆 Transportation Planner</p>', unsafe_allow_html=True)
st.caption("Compare approximate options between popular Indian cities (demo data)")

# Sample route data
routes = {
    ("Delhi", "Agra"): {"distance_km": 230, "flight_hrs": 1.0, "train_hrs": 2.5, "bus_hrs": 4.0, "car_hrs": 3.5},
    ("Delhi", "Jaipur"): {"distance_km": 280, "flight_hrs": 1.1, "train_hrs": 4.5, "bus_hrs": 5.5, "car_hrs": 4.5},
    ("Mumbai", "Goa"): {"distance_km": 590, "flight_hrs": 1.2, "train_hrs": 10, "bus_hrs": 12, "car_hrs": 11},
    ("Bangalore", "Mysore"): {"distance_km": 150, "flight_hrs": None, "train_hrs": 2.5, "bus_hrs": 3.5, "car_hrs": 3.0},
    ("Delhi", "Manali"): {"distance_km": 540, "flight_hrs": None, "train_hrs": None, "bus_hrs": 12, "car_hrs": 12},
    ("Chennai", "Pondicherry"): {"distance_km": 160, "flight_hrs": None, "train_hrs": 4, "bus_hrs": 3.5, "car_hrs": 3.0},
    ("Kolkata", "Darjeeling"): {"distance_km": 620, "flight_hrs": 1.5, "train_hrs": 10, "bus_hrs": 14, "car_hrs": 13},
    ("Delhi", "Leh"): {"distance_km": 1000, "flight_hrs": 1.5, "train_hrs": None, "bus_hrs": None, "car_hrs": 2},  # car via road long
}

cities = sorted(set([c for pair in routes for c in pair]))

c1, c2 = st.columns(2)
with c1:
    origin = st.selectbox("From", cities, index=cities.index("Delhi") if "Delhi" in cities else 0)
with c2:
    dest = st.selectbox("To", [c for c in cities if c != origin], index=0)

key = (origin, dest)
rev_key = (dest, origin)
data = routes.get(key) or routes.get(rev_key)

if not data:
    st.warning("No pre-loaded route for this pair. Try popular combinations like Delhi–Agra, Mumbai–Goa, etc.")
else:
    st.success(f"Approx distance: **{data['distance_km']} km**")

    options = []
    # Rough price estimates
    if data.get("flight_hrs"):
        options.append({"Mode": "✈️ Flight", "Duration (hrs)": data["flight_hrs"],
                        "Est. Price (₹)": int(2500 + data["distance_km"] * 2.5), "Comfort": 5})
    if data.get("train_hrs"):
        options.append({"Mode": "🚆 Train", "Duration (hrs)": data["train_hrs"],
                        "Est. Price (₹)": int(400 + data["distance_km"] * 0.8), "Comfort": 3})
    if data.get("bus_hrs"):
        options.append({"Mode": "🚌 Bus", "Duration (hrs)": data["bus_hrs"],
                        "Est. Price (₹)": int(300 + data["distance_km"] * 0.6), "Comfort": 2})
    if data.get("car_hrs"):
        options.append({"Mode": "🚗 Car / Taxi", "Duration (hrs)": data["car_hrs"],
                        "Est. Price (₹)": int(1500 + data["distance_km"] * 12), "Comfort": 4})

    odf = pd.DataFrame(options)
    st.dataframe(odf, use_container_width=True, hide_index=True)

    fig = px.bar(odf, x="Mode", y="Est. Price (₹)", color="Mode",
                 title="Estimated One-way Cost Comparison", text="Est. Price (₹)")
    fig.update_layout(showlegend=False)
    st.plotly_chart(fig, use_container_width=True)

    fig2 = px.bar(odf, x="Mode", y="Duration (hrs)", color="Mode",
                  title="Travel Time Comparison", text="Duration (hrs)")
    fig2.update_layout(showlegend=False)
    st.plotly_chart(fig2, use_container_width=True)

st.info("💡 Prices and times are approximate demo values for planning only. Check official sites (IRCTC, airline apps, redBus) for live fares.")
