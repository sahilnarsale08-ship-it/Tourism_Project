import streamlit as st
from utils import load_css, set_page_background, PAGE_BACKGROUNDS, load_tourism_data

st.set_page_config(page_title="AI Travel Assistant | TRAVELVERSE", page_icon="🤖", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["ai_assistant"], overlay_opacity=0.78)

st.markdown('<p class="section-header">🤖 AI Travel Assistant</p>', unsafe_allow_html=True)
st.caption("Ask me anything about Indian destinations, packing, itineraries or travel tips (rule-based demo)")

df = load_tourism_data()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = [
        {"role": "bot", "text": "Namaste! 👋 I'm your TRAVELVERSE assistant. Ask me about destinations, best time to visit, packing tips, or request a sample itinerary."}
    ]

# Display history
for msg in st.session_state.chat_history:
    if msg["role"] == "user":
        st.markdown(f'<div class="user-msg">{msg["text"]}</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="bot-msg">{msg["text"]}</div>', unsafe_allow_html=True)

user_input = st.chat_input("Type your travel question...")

def generate_reply(query: str) -> str:
    q = query.lower().strip()
    # Simple rule-based responses
    if any(w in q for w in ["hello", "hi", "namaste", "hey"]):
        return "Hello! Ready to explore India? Tell me a destination or what kind of trip you want."
    if "goa" in q:
        return ("Goa is perfect Nov–Feb. Beaches, nightlife, Portuguese heritage. "
                "Budget ~₹10–15k for 4–5 days. Try North for parties, South for quieter beaches. "
                "Don't miss water sports and seafood!")
    if "manali" in q or "himachal" in q:
        return ("Manali is great Mar–Jun for pleasant weather and adventure (paragliding, rafting). "
                "Winter brings snow. Pack layers. 4–5 days recommended. Old Manali has a relaxed vibe.")
    if "kerala" in q or "backwater" in q or "alleppey" in q:
        return ("Kerala Backwaters (Alleppey/Kumarakom) are magical on a houseboat. "
                "Best Sep–Mar. Combine with Munnar tea gardens. Ayurveda & cuisine are highlights.")
    if "leh" in q or "ladakh" in q:
        return ("Leh-Ladakh is breathtaking Jun–Sep. High altitude – acclimatize 1–2 days. "
                "Monasteries, Pangong Lake, adventure. Budget higher due to logistics. Carry warm clothes even in summer.")
    if "rajasthan" in q or "jaipur" in q or "udaipur" in q or "jaisalmer" in q:
        return ("Rajasthan shines Oct–Mar. Jaipur (Pink City), Udaipur (lakes & palaces), "
                "Jaisalmer (desert & fort). Expect heritage hotels, forts and great food. 7–10 days ideal for a circuit.")
    if "budget" in q or "cost" in q or "cheap" in q:
        return ("Budget tips: Travel by train, stay in hostels/Zostels or mid-range hotels, "
                "eat local, book early. Many destinations can be done under ₹8–12k for 3–4 days excluding flights.")
    if "pack" in q or "packing" in q or "what to bring" in q:
        return ("Packing essentials: light cottons + one warm layer, comfortable walking shoes, "
                "sunscreen, hat, power bank, basic medicines, reusable water bottle. "
                "For hills/deserts adjust for temperature extremes.")
    if "itinerary" in q or "plan" in q:
        return ("I can suggest a sample plan! Tell me: number of days, preferred region "
                "(North/South/East/West/Himalayas), and interests (beach / mountains / heritage / adventure).")
    if "best time" in q or "when to visit" in q or "season" in q:
        return ("General rule: Oct–Mar is peak for most of India (pleasant). "
                "Monsoon (Jun–Sep) for waterfalls & greenery (Kerala, Meghalaya). "
                "Himalayan high-altitude spots best Jun–Sep. Always check local festivals!")
    if "taj" in q or "agra" in q:
        return ("Taj Mahal is best at sunrise. Combine with Agra Fort & Fatehpur Sikri. "
                "1–2 days enough. Wear comfortable shoes and respect the dress code inside.")
    if any(w in q for w in ["thank", "thanks"]):
        return "You're welcome! Happy travels ✈️ Have a wonderful trip across Incredible India!"
    # Fallback – try match destination names
    if not df.empty:
        for _, row in df.iterrows():
            if row["name"].lower() in q or row["city"].lower() in q:
                return (f"**{row['name']}** ({row['city']}, {row['state']})\n\n"
                        f"Category: {row['category']} | Rating: ★{row['rating']}\n"
                        f"Best season: {row['best_season']} | Suggested days: {row['days_recommended']}\n"
                        f"Approx budget: ₹{int(row['estimated_budget']):,}\n\n"
                        f"{row['description']}")
    return ("I'm a demo rule-based assistant. Try asking about Goa, Manali, Kerala, Ladakh, "
            "Rajasthan, packing tips, best season, or budget ideas. Or name any destination from our list!")

if user_input:
    st.session_state.chat_history.append({"role": "user", "text": user_input})
    reply = generate_reply(user_input)
    st.session_state.chat_history.append({"role": "bot", "text": reply})
    st.rerun()

# Quick suggestion chips
st.markdown("#### Quick questions")
chips = ["Best time for Goa", "Packing for Manali", "Kerala itinerary ideas", "Budget tips", "Tell me about Ladakh"]
cols = st.columns(len(chips))
for i, chip in enumerate(chips):
    with cols[i]:
        if st.button(chip, key=f"chip_{i}"):
            st.session_state.chat_history.append({"role": "user", "text": chip})
            st.session_state.chat_history.append({"role": "bot", "text": generate_reply(chip)})
            st.rerun()
