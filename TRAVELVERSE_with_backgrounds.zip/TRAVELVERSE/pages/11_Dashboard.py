import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from utils import load_css, set_page_background, PAGE_BACKGROUNDS, load_tourism_data, get_reviews, get_wishlist

st.set_page_config(page_title="Analytics Dashboard | TRAVELVERSE", page_icon="📊", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["dashboard"], overlay_opacity=0.80)

st.markdown('<p class="section-header">📊 Analytics Dashboard</p>', unsafe_allow_html=True)

df = load_tourism_data()
reviews = get_reviews()
wishlist = get_wishlist()

if df.empty:
    st.warning("No tourism data.")
    st.stop()

# KPIs
k1, k2, k3, k4, k5 = st.columns(5)
k1.markdown(f"""
<div class="kpi-card"><div class="kpi-label">Destinations</div><div class="kpi-value">{len(df)}</div></div>
""", unsafe_allow_html=True)
k2.markdown(f"""
<div class="kpi-card"><div class="kpi-label">States</div><div class="kpi-value">{df['state'].nunique()}</div></div>
""", unsafe_allow_html=True)
k3.markdown(f"""
<div class="kpi-card"><div class="kpi-label">Avg Rating</div><div class="kpi-value">{df['rating'].mean():.2f}</div></div>
""", unsafe_allow_html=True)
k4.markdown(f"""
<div class="kpi-card"><div class="kpi-label">Reviews</div><div class="kpi-value">{len(reviews)}</div></div>
""", unsafe_allow_html=True)
k5.markdown(f"""
<div class="kpi-card"><div class="kpi-label">Wishlist</div><div class="kpi-value">{len(wishlist)}</div></div>
""", unsafe_allow_html=True)

st.write("")

c1, c2 = st.columns(2)
with c1:
    cat_counts = df["category"].value_counts().reset_index()
    cat_counts.columns = ["Category", "Count"]
    fig = px.pie(cat_counts, names="Category", values="Count", title="Destinations by Category",
                 hole=0.4, color_discrete_sequence=px.colors.sequential.Blues)
    st.plotly_chart(fig, use_container_width=True)

with c2:
    state_counts = df["state"].value_counts().head(10).reset_index()
    state_counts.columns = ["State", "Count"]
    fig2 = px.bar(state_counts, x="State", y="Count", title="Top States by Destination Count",
                  color="Count", color_continuous_scale="Blues")
    st.plotly_chart(fig2, use_container_width=True)

c3, c4 = st.columns(2)
with c3:
    fig3 = px.scatter(df, x="estimated_budget", y="rating", size="days_recommended",
                      color="category", hover_name="name",
                      title="Budget vs Rating (size = recommended days)",
                      labels={"estimated_budget": "Est. Budget (₹)", "rating": "Rating"})
    st.plotly_chart(fig3, use_container_width=True)

with c4:
    budget_by_cat = df.groupby("category")["estimated_budget"].mean().sort_values().reset_index()
    fig4 = px.bar(budget_by_cat, x="estimated_budget", y="category", orientation="h",
                  title="Average Budget by Category",
                  labels={"estimated_budget": "Avg Budget (₹)", "category": ""},
                  color="estimated_budget", color_continuous_scale="Teal")
    st.plotly_chart(fig4, use_container_width=True)

if not reviews.empty:
    st.markdown("### Review Insights")
    avg_by_dest = reviews.groupby("destination_name")["rating"].agg(["mean", "count"]).reset_index()
    avg_by_dest = avg_by_dest.sort_values("mean", ascending=False)
    fig5 = px.bar(avg_by_dest, x="destination_name", y="mean",
                  title="Average User Rating per Destination",
                  labels={"mean": "Avg Rating", "destination_name": "Destination"},
                  color="mean", color_continuous_scale="Oranges")
    st.plotly_chart(fig5, use_container_width=True)
