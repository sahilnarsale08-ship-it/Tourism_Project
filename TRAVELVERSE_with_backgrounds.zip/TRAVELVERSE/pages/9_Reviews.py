import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime
from utils import (
    load_css, set_page_background, PAGE_BACKGROUNDS,
    get_reviews, add_review, load_tourism_data
)

st.set_page_config(page_title="Reviews | TRAVELVERSE", page_icon="⭐", layout="wide")
load_css()
set_page_background(PAGE_BACKGROUNDS["reviews"], overlay_opacity=0.78)

st.markdown('<p class="section-header">⭐ Reviews & Ratings</p>', unsafe_allow_html=True)

df = load_tourism_data()
reviews = get_reviews()

tab1, tab2 = st.tabs(["📖 All Reviews", "✍️ Write a Review"])

with tab1:
    if reviews.empty:
        st.info("No reviews yet.")
    else:
        # Charts
        c1, c2 = st.columns(2)
        with c1:
            fig = px.histogram(reviews, x="rating", nbins=5, title="Rating Distribution",
                               color_discrete_sequence=["#0077B6"])
            st.plotly_chart(fig, use_container_width=True)
        with c2:
            top_dest = reviews.groupby("destination_name")["rating"].mean().sort_values(ascending=False).head(8)
            fig2 = px.bar(x=top_dest.index, y=top_dest.values, title="Avg Rating by Destination",
                          labels={"x": "Destination", "y": "Avg Rating"},
                          color_discrete_sequence=["#00B4D8"])
            st.plotly_chart(fig2, use_container_width=True)

        st.markdown("### Recent Reviews")
        for _, r in reviews.iterrows():
            stars = "★" * int(r["rating"]) + "☆" * (5 - int(r["rating"]))
            st.markdown(f"""
            <div class="glass-card">
                <div style="display:flex; justify-content:space-between;">
                    <strong style="color:#023E8A;">{r['destination_name']}</strong>
                    <span style="color:#FF6B35;">{stars}</span>
                </div>
                <p style="margin:0.4rem 0;">{r['review_text']}</p>
                <small style="color:#888;">— {r['user_name']} • {r['date']}</small>
            </div>
            """, unsafe_allow_html=True)

with tab2:
    with st.form("review_form"):
        dest_name = st.selectbox("Destination", df["name"].tolist() if not df.empty else ["Taj Mahal"])
        user_name = st.text_input("Your Name", placeholder="Anonymous Traveller")
        rating = st.slider("Rating", 1, 5, 5)
        text = st.text_area("Your Review", placeholder="Share your experience...")
        submitted = st.form_submit_button("Submit Review")
        if submitted:
            if not user_name.strip() or not text.strip():
                st.error("Please fill name and review text.")
            else:
                dest_id = int(df[df["name"] == dest_name]["id"].iloc[0]) if not df.empty else 0
                add_review(dest_id, dest_name, user_name.strip(), rating, text.strip(),
                           datetime.now().strftime("%Y-%m-%d"))
                st.success("Thank you! Your review has been added.")
                st.rerun()
